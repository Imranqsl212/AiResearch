# Checking the code-repair experiments

Open paper/c5/checker_feedback.pdf for the identified article. From the extracted directory, run:

    python3 -B -m paper.c5.verify_feedback

Python 3.10 or later and the standard library suffice. The verifier checks every listed file digest, all seven main tables, the nine-study roster, historical transitions, returned expressions, functional outcomes and resource counters. The following commands isolate individual findings.

| Question | Offline command |
| --- | --- |
| Does the selected program follow both opposing QuixBugs requirements? | python3 -B -m analysis.quix_contract_reversal_report --check |
| What do the maintainers' original QuixBugs tests report? | python3 -B -m analysis.quix_upstream_tests |
| Which source choices still pass on disjoint expanded inputs? | python3 -B -m analysis.quix_expanded_domain check |
| What happens if the names and definitions of both contracts are omitted? | python3 -B -m analysis.quix_rule_omission_report --check |
| Does changing the caption on an identical value alter choices? | python3 -B -m analysis.output_provenance_report --check |
| What does naming the required convention add? | python3 -B -m analysis.feedback_factorial_report --check |
| Which edits passed the Matplotlib and tqdm maintenance checks? | python3 -B -m analysis.production_patch_report --check |
| Which interval results hold for all scalar endpoint orderings? | python3 -B -m analysis.matplotlib_order_types |
| Which Matplotlib outcomes recur on identical prompts? | python3 -B -m analysis.matplotlib_replication_report --check |
| What happened when these edits ran inside Matplotlib on a real axis? | python3 -B -m analysis.matplotlib_axis_integration_20261128.replay --check |
| How much do CPython replies differ within and between prompts? | python3 -B -m analysis.replicate_display_report --check |
| What exact command repeats appear in the SWE-bench records? | python3 -B -m analysis.swe_recheck --recount |

Add --allow-cd to the SWE-bench command for the documented directory-prefix sensitivity check. Use --fetch instead of --recount to obtain and verify the original public trace bytes over the network. The default packet works offline with the public per-command records. The maintenance study and the SWE-bench trace use different Matplotlib issues. The verification command also checks the 38 controller labels and their 13 explicit requests against the 40 historical episode records, and the stop classes of the 20 public SWE-bench slots.

Each native assignment stays in its original roster. Some identical prompts have one response graded against two possible target contracts. The CPython checkpoints repeat a single sorting defect. The archive preserves the earlier dateutil and CPython timing pilots and contains separate calibration records, target conventions, edited expressions, exclusions and unstarted slots. Each results file binds the corresponding local plan digest. Raw private session streams remain local. Public grades can be reconstructed, while native token extraction and provider identity require other evidence.

Independent human review and the prospective verdict-by-budget experiment remain pending.
