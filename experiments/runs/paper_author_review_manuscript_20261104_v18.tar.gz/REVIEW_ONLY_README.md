# Local author-review manuscript bundle v18

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous PDF/DOCX renderings, article figures, historical derived tables,
references, and pending author decision form. It retains the v17 material
and adds a source-bound historical terminate-latency audit: report, JSON,
recount script, focused test, and SVG. In 14 of 40 historical episodes,
the agent's `terminate` tool call was acknowledged. In 13 later self-labeled
episodes, the median interval from first acknowledgement to final runner
stop was 128.446 seconds. This is observed time, not a counterfactual time
saving or evidence of continued code repair. One acknowledged request ended
in a timeout. These outcomes are retrospective and local to the frozen
adapter/runner.

A separate runtime audit of 208 completed qwen3:4b responses across five
selected excluded v7 cohorts identifies a transient latency burst in one
stopped wave. It includes its report, JSON recount, script, and focused test.
Response-duration arithmetic cannot establish its cause or a feedback effect.

The v17 manuscript-format check passed on remote Linux at source revision
`42aaa05e`. V18 has new scientific text and current local renders of 18
pages; its remote Linux recheck is pending. The bundle contains no raw
trajectories, model requests/responses, source snapshots, or separate run
archives. Its source-hash manifest binds exact selected bytes. Separately
tracked archives are required to replay the historical result.

This review package does not establish human task admission, author approval,
privacy clearance, a journal-accepted data route, or a final Git revision
for the newest material. The anonymous files are review drafts. The
identified decision form must not accompany anonymous peer review.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v18

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, source revision, or journal approval.
