# Local author-review manuscript bundle v15

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous PDF/DOCX renderings, article figures, historical derived tables,
references, and pending author decision form. It retains the v14 analyses
and adds derived reports/JSON for historical protocol stops, sensitivity to
the endpoint definition, and finite test-set sufficiency. It also includes
a descriptive checker-stage SVG and a screened excluded Gemma transfer-pilot
report/JSON. In Gemma's four fixed slots no secure precursor onset occurred,
so no matched feedback arms opened; this is not a measured transfer effect.

The bundle contains no raw trajectories, model requests/responses, source
snapshots, or separate run archives. Its source-hash manifest binds exact
selected bytes. Separately tracked archives and analysis code are needed to
replay findings. This filtered review package does not establish human task
admission, author approval, privacy clearance, a journal-accepted data route,
or a final Git revision for the newest material. The included screen receipt
is a limited pattern check, not a general privacy guarantee.

The anonymous files are review drafts. The identified decision form must
not accompany anonymous peer review. The builder screens selected bytes and
expanded DOCX members for limited local path and account markers; authors
must still inspect the exact package.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v15

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, source revision, or journal approval.
