# Local author-review manuscript bundle v16

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous PDF/DOCX renderings, article figures, historical derived tables,
references, and pending author decision form. It retains the v15 analyses
and adds a derived report, JSON recount, and limited pattern-screen receipt
for the excluded Qwen3:8b capacity probe. The first model request timed out;
the other three slots were unstarted. There was no model response, candidate,
or matched feedback comparison to score. Do not interpret this as a negative
effect or a measured model comparison.

The bundle contains no raw trajectories, model requests/responses, source
snapshots, or separate run archives. Its source-hash manifest binds exact
selected bytes. Separately tracked archives and analysis code are required
to replay findings. This review package does not establish human task
admission, author approval, privacy clearance, a journal-accepted data
route, or a final Git revision for the newest material. The included screen
receipt is a limited pattern check, not general privacy clearance.

The PDFs were rerendered after the v15 remote Linux page-limit failure.
Local rendering and a local simulated fallback meet the 20-page limit;
the remote Linux recheck is pending. The anonymous files are review drafts.
The identified decision form must not accompany anonymous peer review.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v16

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, source revision, or journal approval.
