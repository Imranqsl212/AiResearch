# Local author-review manuscript bundle v17

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous PDF/DOCX renderings, article figures, historical derived tables,
references, and pending author decision form. The derived-report allowlist
matches v16. In the excluded Qwen3:8b capacity probe, the first request
timed out and three slots were unstarted; no matched feedback effect was
measured. The raw run archive is outside this filtered bundle.

The v17 manuscript and renderings incorporate a correction to the PDF font
registration test: fallback rendering now uses Bitstream Vera in a fresh
process rather than accidentally reusing Arial. The current PDFs are 18
pages locally with Arial and 19 pages in a fresh-process Vera render. The
remote Linux recheck after this correction is pending.

The bundle contains no raw trajectories, model requests/responses, source
snapshots, or separate run archives. Its source-hash manifest binds exact
selected bytes. Separately tracked archives and analysis code are required
to replay findings. This review package does not establish human task
admission, author approval, privacy clearance, a journal-accepted data
route, or a final Git revision for the newest material. The included screen
receipt is a limited pattern check, not general privacy clearance.

The anonymous files are review drafts. The identified decision form must
not accompany anonymous peer review.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v17

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, source revision, or journal approval.
