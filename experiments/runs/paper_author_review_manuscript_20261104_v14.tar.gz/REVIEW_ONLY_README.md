# Local author-review manuscript bundle v14

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous canonical and author-year PDF/DOCX renderings, the article figures,
historical derived tables, references, and the pending author decision form.
It adds selected derived reports for the historical feedback audit, first
candidate parity, checker-world sensitivity, source-surrogate AST audit,
and directional error analyses. Two separately selected, excluded live
waves are represented by their reports and JSON recounts. The new six-slot
wave is not pooled with the earlier three-family pilot or the historical
main-study denominator.

`SOURCE_HASH_MANIFEST.json` records exact hashes and byte counts. Raw
trajectories, model requests and responses, candidate source, source snapshots,
and the public run archives are **not** inside this filtered package. Those
separately tracked archives and analysis code are required to replay the
derived findings. This package itself does not establish original-run
provenance, human task admission, author approval, privacy clearance, or a
journal-accepted data route. The newest live-wave data Git revision is
unbound in this bundle; the historical-data revision applies only to an
earlier release.

The anonymous files remain review drafts. The identified author decision
form must not accompany an anonymous peer-review submission. The builder
screens selected bytes and expanded DOCX members for a limited set of local
path and account markers; authors must still inspect the exact package.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v14

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, final source revision, or journal approval.
