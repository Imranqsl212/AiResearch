# Local author-review manuscript bundle v11

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package copies the updated exploratory manuscript, identified and
anonymous canonical and author-year PDF/DOCX files, six figures, historical
derived tables, references, and the pending author decision form. It adds
derived reports and JSON results for the excluded 14-pair persistent-veto
recount and two sequential one-shot v7 pilot waves. These cohorts have
different selection histories and protocols and are not pooled as an
inferential sample or with the historical 40-episode denominator.

`SOURCE_HASH_MANIFEST.json` records each selected file's SHA-256 and byte
count. Raw trajectories, original responses, candidate source, source
snapshots, original archives, and the sanitized review candidate are not
inside this package. The derived reports require separately tracked raw
archives and analysis code for independent replay; this package alone cannot
reproduce their counts from raw traces.

The recorded public Git revision belongs to an older historical data release.
The exact Git revision containing the new pilot archives is pending in this
review package. Git visibility, journal data route, privacy clearance, and
author approval are not attested by this bundle. The anonymous files remain
review drafts; the identified decision form must not accompany an anonymous
peer-review submission.

The builder screens selected bytes and expanded DOCX members for a small set
of local path and account markers. That is not a full privacy or scientific
validity review. Before external distribution, the author must inspect the
exact package and choose an accepted data route.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify \
      --archive experiments/runs/paper_author_review_manuscript_20261101_v11.tar.gz

Use `--no-local-compare` to verify archived bytes and receipt after the
workspace changes. This receipt is a digest, not an independent timestamp,
signature, final source revision, or journal approval.
