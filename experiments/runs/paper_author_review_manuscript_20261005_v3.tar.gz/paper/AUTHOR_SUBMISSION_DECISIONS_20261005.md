# Author submission decision record — pending

This record identifies the exact exploratory manuscript files for **local author
review**. It does not approve journal submission, data release, or the scientific
claims. The author supplied his name, location, and contact in this conversation;
funding, conflicts, acknowledgments, and other declarations will be clarified
separately. Do not infer their absence from a missing response.

## Exact draft under review

| Artifact | Current SHA-256 |
| --- | --- |
| [`final.md`](final.md) | `f6c98b975a34c9ed08167cee316aa42c27b9f97fa13687c57dad40941ba9efaa` |
| [Identified `full_paper.pdf`](submission/full_paper.pdf) | `b52e7243e90a106a4508a5d927c0873665f10073174a110dc0b641d547385901` |
| [Identified `full_paper.docx`](submission/full_paper.docx) | `ab11da57a166bb7dd634f97404f1dbcd862cd3b3fe46e318dbb3c8c0861e8668` |
| [Anonymous `full_paper_anonymous.pdf`](submission/full_paper_anonymous.pdf) | `3fcc3b8b9a812f2805af5c944c7788d60b98ce624c0f56df0b3d73f124c711de` |
| [Anonymous `full_paper_anonymous.docx`](submission/full_paper_anonymous.docx) | `615b9cdba93e2c6f38f2b1be59190c1278e7064fe40e333033b453efd5bdc16e` |
| [`results.json`](artifacts/results.json) | `3d7ef25bfa07ef25ae20cea8d6ee34b59c5d9158e20c2e9b7013bfbd5a3cb229` |

The identified PDF has 16 A4 pages and the anonymous PDF has 15. PDF text,
including captions and tables, is 12 pt;
the DOCX styles are 12 pt with single line spacing. The abstract has 237 words
and the article contains six figures and four tables. The identified and
anonymous PDF/DOCX pairs regenerated with identical hashes on this workspace.
The anonymous files have blank author metadata and automated scans found no
author name, contact, location, or study-commit marker in their content. Word
page count and final venue compliance must be checked in the journal's editor.

These hashes identify this review draft only. Recompute them and repeat
scientific review after any manuscript, analysis, or rendering change. The
final reviewed source revision and exact data package must be recorded together.

## Decisions to record

| Decision | Required human entry | Current status |
| --- | --- | --- |
| Venue | Journal/conference, article type, checked author guidelines and date | `PENDING` |
| Authors and contact | Ordered full names, affiliation and corresponding author | `PARTIAL`: Imran Zakirov; independent student researcher without institutional affiliation; Bishkek, Kyrgyzstan; zakirovimran333@gmail.com. Sole authorship and wording need final author approval. |
| Contributions | Approved contribution statement from all named authors | `PENDING` |
| Declarations | Funding, conflicts, acknowledgments, ethics and required AI-tool disclosure | `PENDING`: author said details will follow separately. Codex assistance is disclosed in the draft for author review. |
| Scientific sign-off | Authors approve the exact exploratory claims and limitations in the hashed draft | `PENDING` |
| Data route | Actual public deposit, approved controlled-access procedure, or journal-approved exception, with location/custodian | `PENDING` |
| Privacy sign-off | Human review of the sanitized archive and all free text, with disposition of residual candidates | `PENDING` |
| Final package | Venue formatting, final hashes, source revision, supplementary files, cover letter and submission account | `PENDING` |

The current sanitized review candidate has SHA-256
`48720a5620a1437094268452caab8f0168516454166147e575dea1c1039c0dd3`.
Its Git-ignored [private inspection report](../experiments/runs/paper_sanitized_privacy_packet_20261005_v2/PRIVATE_INSPECTION_REPORT.json)
has SHA-256
`efc747fec81e94b972a408cc496e22702969eb477ca2917164687df2654c4841`.
The report lists eight remaining path candidates and 457 lexical review
leads. Those numbers are a review worklist, not clearance; the report and
archive are not approved supplements.

See the [submission handoff](SUBMISSION_HANDOFF_20261005.md),
[data-availability options](DATA_AVAILABILITY_OPTIONS_20261005.md), and
[venue shortlist](VENUE_SHORTLIST_20261005.md). This local form includes author
identity and must not be uploaded as an anonymous peer-review supplement.
