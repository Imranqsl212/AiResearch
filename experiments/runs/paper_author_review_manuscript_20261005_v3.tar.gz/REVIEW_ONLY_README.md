# Local author-review manuscript bundle v3

**Status: REVIEW_ONLY. Public release and journal submission are not approved.**

This package contains exact copies of the revised exploratory manuscript,
identified and anonymous PDF/DOCX files, six figures, historical derived
tables, and separate derived audits for the excluded 30-episode corrected-
oracle pilot and its one matched continuation. It also includes the source-
fidelity inventory, a proposed strategy-coding protocol, references, the
cover-letter template, data-availability options, and the author decision
form. The pilot is not pooled with the historical 40-episode denominator.

`SOURCE_HASH_MANIFEST.json` records each selected file's SHA-256 and byte
count. `paper/artifacts/input_hashes.csv` is the historical input ledger;
the original raw inputs, local pilot trajectories, source snapshots, model
responses, private archives, and sanitized candidate are not included.
This package cannot reproduce the original-run or pilot evidence chains from
raw traces by itself. The author decision form binds the current manuscript,
rendered pairs, and historical derived results by hash. All scientific,
privacy, venue, identity, declaration, and data-access decisions remain open.

The builder screens selected bytes and expanded DOCX members for a small set
of local path and account markers. This does not establish privacy clearance
for all free text, metadata, images, or scientific validity. The anonymous
copies are review drafts, not approved submissions.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify \
      --archive experiments/runs/paper_author_review_manuscript_20261005_v3.tar.gz

Use `--no-local-compare` to verify archived bytes and receipt after the
workspace changes. No final Git revision, independent timestamp, or digital
signature is bound. The SHA-256 receipt detects accidental changes when
checked against a trusted copy.
