# Local author-review manuscript bundle v2

**Status: REVIEW_ONLY. Public release and journal submission are not approved.**

This package contains exact copies of the current exploratory manuscript,
identified and anonymous PDF/DOCX files, six figures, references, derived
result tables, the cover-letter template, data-availability options, and the
author decision form. `SOURCE_HASH_MANIFEST.json` records each selected source
file's SHA-256 and byte count. `paper/artifacts/input_hashes.csv` is the paper's
historical input ledger; those raw inputs are **not** included here.

The package excludes raw trajectories, original responses, private source
snapshots, the private original-byte archive, the sanitized review candidate,
and unrelated historical JSON. It cannot reproduce historical numbers from
original trajectories by itself. The author decision form binds the manuscript,
both rendered file pairs, and derived results by hash, while recording pending
scientific, privacy, venue, identity, declaration, and data-access decisions.

The anonymous files are drafts for peer review. The builder screens selected
bytes and expanded DOCX members for a small set of local home-path and account
markers. This automated screen does not clear free text, metadata, images,
privacy, or scientific validity. Authors must review exact files and choose
an approved data route before any external distribution.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify \
      --archive experiments/runs/paper_author_review_manuscript_20261005_v2.tar.gz

Use `--no-local-compare` to verify the archived bytes and receipt after the
workspace sources have changed. No Git commit, model run, raw-data replay,
independent timestamp, or digital signature is bound to this archive. The
SHA-256 receipt detects accidental changes only when checked against a trusted
copy of that receipt.
