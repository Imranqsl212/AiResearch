# Author submission decision record — pending

This record identifies the exact exploratory manuscript files for **local author
review**. It does not approve journal submission, data release, or the scientific
claims. The author supplied his name, location, and contact in this conversation;
funding, conflicts, acknowledgments, and other declarations will be clarified
separately. Do not infer their absence from a missing response.

## Exact draft under review

| Artifact | Current SHA-256 |
| --- | --- |
| [`final.md`](final.md) | `9fd72391ce50610e39aa740eae81f2b90f41c014fc3420b0642c702174f8ccbc` |
| [Identified `full_paper.pdf`](submission/full_paper.pdf) | `09944f1a16dd85fa38b148644ee4a7da24b38e1564dd30580afeedfde355ddf0` |
| [Identified `full_paper.docx`](submission/full_paper.docx) | `8f007fdc47ae1154aed895b9760f083950beaa93358c642ef882c4cfe3479d8f` |
| [Anonymous `full_paper_anonymous.pdf`](submission/full_paper_anonymous.pdf) | `6f7b86084d85b9a8bddecb7949bdc5ba12f88837da8404bb892f012420958d2c` |
| [Anonymous `full_paper_anonymous.docx`](submission/full_paper_anonymous.docx) | `03aa7be5a74efc04555151f6150c15325528079997dec8412c2159315cb435d2` |
| [`results.json`](artifacts/results.json) | `3d7ef25bfa07ef25ae20cea8d6ee34b59c5d9158e20c2e9b7013bfbd5a3cb229` |

Both PDFs have 14 A4 pages. PDF text, including captions and tables, is 12 pt;
the DOCX styles are 12 pt with single line spacing. The abstract has 234 words
and the article contains six figures and three tables. The identified and
anonymous PDF/DOCX pairs regenerated with identical hashes on this workspace.
The anonymous files have blank author metadata and automated scans found no
author name, contact, location, or study-commit marker in their content. Word
page count and final venue compliance must be checked in the journal's editor.

These hashes identify this review draft only. Recompute them and repeat
scientific review after any manuscript, analysis, or rendering change. The
final reviewed source revision and exact data package must be recorded together.

## Decisions to record

| Decision | Required human entry | Current status |
| --- | --- | --- |
| Venue | Journal/conference, article type, checked author guidelines and date | `PENDING` |
| Authors and contact | Ordered full names, affiliation and corresponding author | `PARTIAL`: Imran Zakirov; independent student researcher without institutional affiliation; Bishkek, Kyrgyzstan; zakirovimran333@gmail.com. Sole authorship and wording need final author approval. |
| Contributions | Approved contribution statement from all named authors | `PENDING` |
| Declarations | Funding, conflicts, acknowledgments, ethics and required AI-tool disclosure | `PENDING`: author said details will follow separately. Codex assistance is disclosed in the draft for author review. |
| Scientific sign-off | Authors approve the exact exploratory claims and limitations in the hashed draft | `PENDING` |
| Data route | Actual public deposit, approved controlled-access procedure, or journal-approved exception, with location/custodian | `PENDING` |
| Privacy sign-off | Human review of the sanitized archive and all free text, with disposition of residual candidates | `PENDING` |
| Final package | Venue formatting, final hashes, source revision, supplementary files, cover letter and submission account | `PENDING` |

The current sanitized review candidate has SHA-256
`48720a5620a1437094268452caab8f0168516454166147e575dea1c1039c0dd3`.
Its Git-ignored [private inspection report](../experiments/runs/paper_sanitized_privacy_packet_20261005_v2/PRIVATE_INSPECTION_REPORT.json)
has SHA-256
`efc747fec81e94b972a408cc496e22702969eb477ca2917164687df2654c4841`.
The report lists eight remaining path candidates and 457 lexical review
leads. Those numbers are a review worklist, not clearance; the report and
archive are not approved supplements.

See the [submission handoff](SUBMISSION_HANDOFF_20261005.md),
[data-availability options](DATA_AVAILABILITY_OPTIONS_20261005.md), and
[venue shortlist](VENUE_SHORTLIST_20261005.md). This local form includes author
identity and must not be uploaded as an anonymous peer-review supplement.
