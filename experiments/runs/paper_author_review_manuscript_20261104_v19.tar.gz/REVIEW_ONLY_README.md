# Local author-review manuscript bundle v19

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current exploratory manuscript, identified and
anonymous PDF/DOCX renderings, figures, historical derived tables,
references, and pending author decision form. It retains the v18 material
and adds two verified source-bound controls: an adversarial audit of the
historical terminate-latency interpretation and a model-free control of the
frozen runner's stop handshake. The corrected historical latency report,
JSON, script, and SVG are bound to their current bytes.

The 14 historical episodes with an acknowledged `terminate` call occurred
only in nominally repairable cells after a public `SECURITY_CHECK_PASSED`
message. Those episodes contain 15 calls because one episode called twice.
The 128.446-second median acknowledgement-to-stop interval in 13 later
self-labeled episodes is an observed success-path handshake interval, not
time spent deciding that an unavailable task was impossible or a measured
counterfactual time saving. The model-free control shows that the frozen
runner requires a subsequent adapter stop decision after `STOP_REQUESTED`.
It does not estimate the historical model's intent or a feedback effect.

The current identified and anonymous PDFs have 18 pages locally with Arial
and 19 pages in a fresh-process Bitstream Vera render. The current v19
remote Linux recheck is pending. The package includes the rendering test
that checks the 200–250-word abstract range. The bundle contains no raw trajectories,
model requests/responses, source snapshots, or separate run archives. Its
source-hash manifest binds exact selected bytes. Separately tracked sealed
logs are required to replay the historical findings.

This review package does not establish human task admission, author approval,
privacy clearance, a journal-accepted data route, or a final Git revision
for the newest material. The anonymous files are review drafts. The
identified decision form must not accompany anonymous peer review.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v19

Use `--no-local-compare` to verify archived bytes and receipt after workspace
sources change. This digest receipt is not an independent timestamp,
signature, source revision, or journal approval.
