# Local author-review manuscript bundle

**Status: REVIEW_ONLY. Public release and journal submission are not approved.**

This package contains exact copies of the current exploratory manuscript,
rendered PDF and DOCX, six figures, references, derived result tables, the
cover-letter template, data-availability options, and the author decision form.
`SOURCE_HASH_MANIFEST.json` records each selected source file's SHA-256 and byte
count. `paper/artifacts/input_hashes.csv` is the paper's historical input
ledger; the inputs named there are **not** included in this package.

The package deliberately excludes raw trajectories, original responses,
private source snapshots, the private original-byte archive, the sanitized
review candidate, and unrelated historical JSON. It cannot reproduce the
historical numbers from original trajectories by itself. Its derived tables
and source hashes support author inspection, not an independent replay of
the original evidence chain. The author decision form records open scientific,
privacy, venue, identity, declaration, and data-access decisions.

The builder rejects selected files containing a small set of local home-path
and account markers. This automated screen does not clear free text, metadata,
images, privacy, or scientific validity. Authors must review the exact files
and choose an approved data route before any external distribution.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify \
      --archive experiments/runs/paper_author_review_manuscript_20261005_v1.tar.gz

No Git commit, model run, raw-data replay, independent timestamp, or digital
signature is bound to this archive. The SHA-256 receipt identifies the local
package bytes and detects accidental changes when checked against a trusted
copy of that receipt.
