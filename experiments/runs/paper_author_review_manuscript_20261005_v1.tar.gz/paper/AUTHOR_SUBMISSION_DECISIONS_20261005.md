# Author submission decision record — pending

This form is for the human submitting authors. It contains no inferred
identity, consent, privacy approval, or journal acceptance. The current
exploratory manuscript is a review draft. Fill sensitive contact details in
a private copy if they should not enter Git history.

## Exact draft under review

| Artifact | Current SHA-256 |
| --- | --- |
| [`final.md`](final.md) | `7aa6fb3643d91c17678d74cd6716396c770db2be15302a5ad4864684d4603a69` |
| [`full_paper.pdf`](submission/full_paper.pdf) | `738b1a941760d6bd923804c1c92cf97cc8fbab87ba22ed92dcd39a473ab8eade` |
| [`full_paper.docx`](submission/full_paper.docx) | `3ffe78c9d6b8e6efefe75569c8d294aa65bdf78ab9175e638a0d13645161765a` |
| [`results.json`](artifacts/results.json) | `3d7ef25bfa07ef25ae20cea8d6ee34b59c5d9158e20c2e9b7013bfbd5a3cb229` |

These hashes identify today's draft only. Recompute them and repeat scientific
review after any manuscript, analysis, or rendering change. A final reviewed
source revision and its exact data package must be recorded together.
The PDF now uses ReportLab's invariant metadata, and the DOCX ZIP member
timestamps are normalized. Two consecutive builds on this workspace produced
the same PDF and DOCX hashes; cross-platform byte identity is not established.

## Decisions to record

| Decision | Required human entry | Current status |
| --- | --- | --- |
| Venue | Journal/conference, article type, checked author guidelines and date | `PENDING` |
| Authors | Ordered full names, affiliations, corresponding author and contact | `PENDING` |
| Contributions | Approved contribution statement from all named authors | `PENDING` |
| Declarations | Funding, conflicts, ethics, and required tool-use disclosures | `PENDING` |
| Scientific sign-off | Authors approve the exact exploratory claims and limitations in the hashed draft | `PENDING` |
| Data route | Actual public deposit, approved controlled-access procedure, or journal-approved exception, with location/custodian | `PENDING` |
| Privacy sign-off | Human review of the sanitized archive and all free text, with disposition of residual candidates | `PENDING` |
| Final package | Venue formatting, final hashes, source revision, supplementary files, cover letter and submission account | `PENDING` |

The current sanitized review candidate has SHA-256
`48720a5620a1437094268452caab8f0168516454166147e575dea1c1039c0dd3`.
Its Git-ignored [private inspection report](../experiments/runs/paper_sanitized_privacy_packet_20261005_v2/PRIVATE_INSPECTION_REPORT.json)
has SHA-256
`efc747fec81e94b972a408cc496e22702969eb477ca2917164687df2654c4841`.
The report lists eight remaining path candidates and 457 lexical review
leads. Those numbers are a review worklist, not clearance; the report and
archive are not approved supplements.

See the [submission handoff](SUBMISSION_HANDOFF_20261005.md),
[data-availability options](DATA_AVAILABILITY_OPTIONS_20261005.md), and
[venue shortlist](VENUE_SHORTLIST_20261005.md) for the evidence and conditional
wording. Do not replace a pending decision with an assumed author preference.
