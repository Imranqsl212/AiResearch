# Local author-review manuscript bundle v20

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package binds the current manuscript, identified and anonymous PDF/DOCX
renderings, figures, references, historical derived tables, and pending author
decision form. It retains the v19 allowlist and adds curated results from the
external discovery audit, the SWE-agent submission census, the OpenHands
coverage census, and the controlled, model-free export projection. These
studies keep their separate populations and evidentiary limits. The projection
records include explicitly simulated responses; they do not recover missing
historical responses or establish historical stopping causes.

The seven added files contain summaries, a report, controlled-pair results,
and an execution receipt. This curated review package is not the full
reproduction package: the referenced protocols, scripts, per-issue records,
source manifests, and public source collections remain separate. The package
contains no raw trajectories, actual model requests/responses, source caches,
or separate run archives. Packaging performs no model run or new empirical
study. Its source-hash manifest binds exact selected bytes, not the scientific
validity or original-run provenance of their contents.

The author decision form binds the current draft and selected derived files;
it does not record scientific sign-off. Author approval, declarations, privacy
clearance, the journal data route, and the final source revision remain
pending. The anonymous files are review drafts. The identified decision form
must not accompany anonymous peer review. The automated path screen does not
replace human review of text, metadata, or images.

Verify against the current local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --bundle-version v20

Earlier versioned archives remain frozen. Use `--no-local-compare` to verify
their archived bytes and receipts after workspace sources change. This digest
receipt is not an independent timestamp, signature, or journal approval.
