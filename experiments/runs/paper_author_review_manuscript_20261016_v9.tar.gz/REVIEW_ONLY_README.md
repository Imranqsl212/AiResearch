# Local author-review manuscript bundle v9

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package contains exact copies of the corrected exploratory manuscript,
identified and anonymous PDF/DOCX files, six figures, references, historical
derived tables, and separate audits for the excluded corrected-oracle pilot.
It also contains the source-fidelity inventory, strategy-coding protocol,
cover-letter template, data-availability options, and author decision form.
The pilot is not pooled with the historical 40-episode denominator.

The cover-letter template identifies the public GitHub data revision 37074c198237ade67eb76921333b2835d329c863. Historical and pilot archives, analysis code, and derived tables are publicly tracked there. Its bracketed data-and-code paragraph still needs author review of journal wording and privacy before submission. This filtered review package itself is not an approved journal supplement. The cited data revision does not attest to this v9 package's contents.

The manuscript corrects the interpretation of the hidden acceptance veto,
recorded stopping labels, logger-redacted source, and fixed family guidance.
Some historical derived artifacts retain exploratory calculations that the
current article omits or no longer interprets as population estimates. Those
artifacts preserve the earlier analysis record; their presence is not a claim
of statistical significance, verified stopping intent, or secure code.

`SOURCE_HASH_MANIFEST.json` records each selected source file's SHA-256 and byte
count. `paper/artifacts/input_hashes.csv` is the historical input ledger.
Raw trajectories, original responses, source snapshots, original archives,
and the sanitized review candidate are not inside this filtered package;
they are tracked separately. The included audit scripts need those separate
inputs for replay. This package alone cannot regenerate the reported results
from raw traces.

The builder screens selected bytes and expanded DOCX members for a small set
of local path and account markers. This does not establish privacy clearance
for all free text, metadata, images, or scientific validity. The anonymous
files are review drafts. Author decisions on claims, declarations, journal
data route, privacy, and venue requirements remain open.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify \
      --archive experiments/runs/paper_author_review_manuscript_20261016_v9.tar.gz

Use `--no-local-compare` to verify archived bytes and receipt after the
workspace changes. No final Git revision, independent timestamp, or digital
signature is bound to this package. A SHA-256 receipt detects accidental
changes when checked against a trusted copy.
