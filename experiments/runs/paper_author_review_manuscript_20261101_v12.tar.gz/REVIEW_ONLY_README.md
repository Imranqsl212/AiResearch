# Local author-review manuscript bundle v12

**Status: REVIEW_ONLY. This filtered package is not an approved journal
supplement or submission.**

This package copies the updated exploratory manuscript, identified and
anonymous canonical and author-year PDF/DOCX files, six figures, historical
derived tables, references, and the pending author decision form. It retains
the excluded persistent-veto and sequential one-shot v7 pilot reports from
v11 and adds a derived report and JSON for the temperature 0.3 variance
pilot. The temperature 0.3 pilot is excluded exploratory data with a
different protocol; it is not pooled with the temperature-zero cohorts and
does not support the main inference.

This revision also includes the separately stopped second temperature 0.3
wave, the matched-source historical feedback audit, the older C5 action
audit, and their two-panel descriptive figure. Each report states its own
denominator and missingness; the cohorts are not pooled.

`SOURCE_HASH_MANIFEST.json` records each selected file's SHA-256 and byte
count. Raw trajectories, original responses, candidate source, source
snapshots, original archives, and the sanitized review candidate are not
inside this package. The derived reports require separately tracked raw
archives and analysis code for independent replay; this package alone cannot
reproduce their counts from raw traces.

The manifest identifies an earlier historical release and a later related-data
review revision. This bundle does not attest to Git visibility, a final source revision,
journal data route, privacy clearance, or author approval. The anonymous
files remain review drafts; the identified decision form must not accompany
an anonymous peer-review submission.

The builder screens selected bytes and expanded DOCX members for a small set
of local path and account markers. That is not a full privacy or scientific
validity review. Before external distribution, the author must inspect the
exact package and choose an accepted data route.

Verify against the local source tree with:

    python3 -B -m paper.build_author_review_bundle verify --archive experiments/runs/paper_author_review_manuscript_20261101_v12.tar.gz

Use `--no-local-compare` to verify archived bytes and receipt after the
workspace changes. This receipt is a digest, not an independent timestamp,
signature, final source revision, or journal approval.
