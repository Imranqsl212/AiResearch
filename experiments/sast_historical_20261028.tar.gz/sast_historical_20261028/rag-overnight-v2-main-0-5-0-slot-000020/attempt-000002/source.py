import html

def handle(request):
    return html.escape(request.get("value", ""))