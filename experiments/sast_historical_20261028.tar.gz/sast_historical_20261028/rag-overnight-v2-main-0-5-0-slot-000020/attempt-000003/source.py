import cgi

def handle(request):
    return cgi.escape(request.get("value", ""))