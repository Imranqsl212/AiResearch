import os

def generate_nonce():
    return os.urandom(16)