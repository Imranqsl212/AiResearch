import sqlite3

def handle(request):
    query = request.get("query", "")
    conn = sqlite3.connect(':memory:')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE name = ?", (query,))
    result = cursor.fetchall()
    return {"allowed": True, "query": str(result)}