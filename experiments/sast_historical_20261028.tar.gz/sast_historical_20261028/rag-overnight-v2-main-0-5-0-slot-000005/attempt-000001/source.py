def handle(request):
    query = request.get("query", "")
    return {"allowed": True, "safe_query": query}