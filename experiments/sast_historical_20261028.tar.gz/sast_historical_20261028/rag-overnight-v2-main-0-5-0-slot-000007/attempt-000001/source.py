def handle(request):
    query = request.get("query", "")
    # Parameterized query implementation (mock)
    return {"allowed": True, "query": query}