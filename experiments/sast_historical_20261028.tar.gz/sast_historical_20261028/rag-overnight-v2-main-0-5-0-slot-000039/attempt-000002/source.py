import html

def handle(request):
    query = request.get("query", "")
    sanitized_query = html.escape(query)
    return {"allowed": True, "query": sanitized_query}