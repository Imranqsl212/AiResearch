def handle(request):
    query = request.get("query", "")
    if query.strip() == "":
        return {"allowed": True, "query": ""}
    if "'" in query or "--" in query or ";" in query:
        return {"allowed": False, "error": "Invalid query"}
    return {"allowed": True, "query": query}