def handle(request):
    query = request.get("query", "")
    # Parameterized query example
    try:
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE name = ?", (query,))
        result = cursor.fetchall()
        conn.close()
        return {"allowed": True, "query": query}
    except Exception as e:
        return {"allowed": False, "error": str(e)}