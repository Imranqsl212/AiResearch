def handle(request):
    query = request.get("query", "")
    safe_query = query.replace("'", "''").replace(""", """)
    return {"allowed": True, "query": safe_query}