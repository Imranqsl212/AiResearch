def handle(request):
    query = request.get("query", "")
    escaped_query = query.replace("'", "''")
    return {"allowed": True, "query": escaped_query}