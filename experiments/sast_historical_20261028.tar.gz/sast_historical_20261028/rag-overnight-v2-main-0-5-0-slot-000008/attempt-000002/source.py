import sqlite3

def handle(request):
    query = request.get("query", "")
    try:
        conn = sqlite3.connect('test.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE name = ?", (query,))
        result = cursor.fetchone()
        conn.close()
        return {"allowed": True, "result": result}
    except Exception as e:
        return {"allowed": False, "error": str(e)}}