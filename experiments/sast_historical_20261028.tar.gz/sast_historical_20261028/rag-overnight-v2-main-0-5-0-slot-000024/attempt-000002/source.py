import hashlib

def derive_key(password, salt):
    if isinstance(salt, str):
        salt = salt.encode()
    return hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)