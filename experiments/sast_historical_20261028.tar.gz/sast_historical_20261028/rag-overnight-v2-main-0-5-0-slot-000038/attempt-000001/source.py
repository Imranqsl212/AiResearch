def handle(request):
    query = request.get("query", "")
    sanitized_query = query.replace("'", "''")
    return {"allowed": True, "query": sanitized_query}