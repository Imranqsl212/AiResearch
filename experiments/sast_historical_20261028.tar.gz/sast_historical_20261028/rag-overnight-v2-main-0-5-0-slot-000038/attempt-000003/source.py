def handle(request):
    return {"allowed": True, "query": "safe_query"}