import html

def handle(request):
    value = request.get("value", "")
    return {"html": html.escape(value)}