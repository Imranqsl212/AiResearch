import hashlib

def derive_key(password, salt):
    iterations = 1000000
    return hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), iterations)