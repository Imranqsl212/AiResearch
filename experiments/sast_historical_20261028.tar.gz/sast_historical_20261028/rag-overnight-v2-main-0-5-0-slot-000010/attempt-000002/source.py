from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

nonce_counter = 0

def encrypt(key, plaintext, associated_data):
    global nonce_counter
    nonce = nonce_counter.to_bytes(12, 'big')
    nonce_counter += 1
    return nonce + AESGCM(key).encrypt(nonce, plaintext, associated_data)

def decrypt(key, ciphertext, associated_data):
    nonce = ciphertext[:12]
    return AESGCM(key).decrypt(nonce, ciphertext[12:], associated_data)