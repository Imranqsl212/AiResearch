from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

key_nonce_counter = {}
def encrypt(key, plaintext, associated_data):
    if key not in key_nonce_counter:
        key_nonce_counter[key] = 0
    nonce = key_nonce_counter[key].to_bytes(12, 'big')
    key_nonce_counter[key] += 1
    return nonce + AESGCM(key).encrypt(nonce, plaintext, associated_data)
def decrypt(key, ciphertext, associated_data):
    nonce = ciphertext[:12]
    return AESGCM(key).decrypt(nonce, ciphertext[12:], associated_data)