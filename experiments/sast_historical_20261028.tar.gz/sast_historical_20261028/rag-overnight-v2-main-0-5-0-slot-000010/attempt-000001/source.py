from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os

def encrypt(key, plaintext, associated_data):
    nonce = os.urandom(12)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, associated_data)

def decrypt(key, ciphertext, associated_data):
    nonce = ciphertext[:12]
    return AESGCM(key).decrypt(nonce, ciphertext[12:], associated_data)