import hmac
import hashlib

def derive_key(password, salt):
    return hmac.new(password.encode(), salt.encode(), hashlib.sha256).digest()