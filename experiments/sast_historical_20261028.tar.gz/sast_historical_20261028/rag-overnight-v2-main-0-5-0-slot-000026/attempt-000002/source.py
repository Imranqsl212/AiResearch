import html

def handle(request):
    value = request.get("value", "")
    return html.escape(value)