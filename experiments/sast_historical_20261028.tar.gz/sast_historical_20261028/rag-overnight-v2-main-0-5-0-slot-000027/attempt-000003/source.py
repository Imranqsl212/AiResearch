import html

def handle(request):
    value = request.get("value", "")
    return f"<div>{html.escape(value)}</div>"